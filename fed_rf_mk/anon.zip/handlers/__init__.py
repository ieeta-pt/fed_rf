"""Handlers for analysis outputs like SHAP and PFI."""

